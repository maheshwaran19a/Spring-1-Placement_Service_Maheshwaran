package com.tnsif.collegeservice;

import org.springframework.data.jpa.repository.JpaRepository;

public interface College_Service_Repository extends  JpaRepository<College, Integer>
{

}
