package com.tnsif.collegeservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacementManagementCollegeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacementManagementCollegeServiceApplication.class, args);
	}

}
